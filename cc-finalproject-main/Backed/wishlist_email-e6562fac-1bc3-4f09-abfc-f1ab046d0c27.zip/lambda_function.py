import json
import boto3



def send_ses(email, formed_email):

    client = boto3.client('ses')
    # print(sender_email)
    response = client.send_email(
        Source="customer@yukizhang.today",
        Destination={
            'ToAddresses': [
                email
            ]},
        Message={
            'Subject': {
                'Data': "The tag you subscribed has new products for sale"
            },
            'Body': {
                'Text': {
                    'Data': formed_email
                }
            }
        })
        
    print(response)


def lambda_handler(event, context):
    print(event)
    
    for message in event["Records"]:
        ReceiptHandler = message["receiptHandle"]
        email, body = message["body"].split("|")
        send_ses(email, body)
        client = boto3.client('sqs')
        response = client.delete_message(
            QueueUrl='https://sqs.us-east-1.amazonaws.com/439468506220/final.fifo',
            ReceiptHandle=ReceiptHandler
        )
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
