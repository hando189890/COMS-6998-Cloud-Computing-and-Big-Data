import json
import boto3
import requests
import base64
import smtplib
from base_rdb_service import BaseDataResource
from datetime import datetime
import uuid

DB_SCHEMA = "6998db"
TABLE = "wish_list"
PRODUCT_TABLE = "Product"
USER_TABLE = "User"
PRODUCT_TAG_TABLE = "product_tag"

def find_subscribe_tags():
    group = "tag"
    template = None
    
    res = BaseDataResource.find_distinct_value(DB_SCHEMA, TABLE, template, group)
    
    print(res)
    
    distinct_tags = []
    for tag in res:
        distinct_tags.append(tag["tag"])

    return distinct_tags
    
def find_distinct_new_pid(distinct_tags):
    now = datetime.now()
    dt_string = now.strftime("%Y/%m/%d %H:%M:%S")
    dt_obj = datetime.strptime(dt_string, '%Y/%m/%d %H:%M:%S')
    created_time = dt_string
    products = {}
    for tag in distinct_tags:
        # print("tag: ", tag)
        template = {"tag": tag}
        res = BaseDataResource.find_by_template(DB_SCHEMA, PRODUCT_TAG_TABLE, template=template)
        # print(res)
        products[tag] = []
        for product in res:
            pid = product["pid"]
            template = {"pid": pid, "is_deleted": 0}
            res = BaseDataResource.find_by_template(DB_SCHEMA, PRODUCT_TABLE, template=template, created_date=created_time, days=7)
            # print(type(res), len(res))
            if len(res) == 1:
                # print("res: ", res[0])
                products[tag].append(res[0])
                
    print(products)
    
    return products

def find_subscribe_users(products):
    group = "uid"
    
    uids = BaseDataResource.find_distinct_value(DB_SCHEMA, TABLE, None, group)
    
    for user in uids:
        uid = user["uid"]
        template = {"uid": uid}
        tags = BaseDataResource.find_by_template(DB_SCHEMA, TABLE, template=template)
        email_info = {}
        for t in tags:
            tag = t["tag"]
            if len(products[tag]) > 0:
                email_info[tag] = products[tag]
        print(uid, email_info)
        if len(email_info) != 0:
            formed_email = formated_email(email_info)
            send_to_sqs(uid, formed_email)
        
    
def formated_email(email_info):
    formed_email = "Dear Customer, there are some new products on sale. You are receiving this email since you have subscribed to the tags.\n"
    formed_email += "You can check the product details as following: \n"
    for tag in email_info:
        formed_email += tag + ": \n"
        for product in email_info[tag]:
            formed_email += "Product Name: " + product["name"] + "; Price: " + str(product["price"]) + "; Description: " + product["description"] + '\n'
        

    return formed_email
    
        
def send_to_sqs(uid, formed_email):
    res = BaseDataResource.find_by_template(DB_SCHEMA, USER_TABLE, template={'uid':uid})
    
    email = res[0]["email"]
    session = boto3.Session()

    sqs_client = session.client(
        service_name='sqs',
        endpoint_url='https://sqs.us-east-1.amazonaws.com',
    )
    
    sqs_client.send_message(
        QueueUrl='https://sqs.us-east-1.amazonaws.com/439468506220/final.fifo',
        MessageBody=email + '|' +formed_email,
        MessageGroupId ="1",
        MessageDeduplicationId=uuid.uuid4().hex
    )
    

def lambda_handler(event, context):
    # TODO implement
    distinct_tags = find_subscribe_tags()
    # print(distinct_tags)
    # print(distinct_tags)
    products = find_distinct_new_pid(distinct_tags)
    find_subscribe_users(products)
    # print("a")
    #test()
    #send_email("email-smtp.us-east-1.amazonaws.com", "587", "AKIAWMUS5HRWBTURW7WI", "BEtRT2OH0Rxl/zG8KtzSAxxTxBw3Q0rVHktt7DGu32rX", "hi", "hello body", "yz3983@columbia.edu", "customer@yukizhang.today")
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
