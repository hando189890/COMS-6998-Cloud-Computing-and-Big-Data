import os
import pymysql


def get_db_info():
    """
    This is crappy code.

    :return: A dictionary with connect info for MySQL
    """
    
    db_host = "shopcolumbia.cqik3qw0ql6b.us-east-1.rds.amazonaws.com"
    db_user = "admin"
    db_password = "CC6998cc"

    db_info = {
        "host": db_host,
        "user": db_user,
        "password": db_password,
        "cursorclass": pymysql.cursors.DictCursor
    }
    
    return db_info
