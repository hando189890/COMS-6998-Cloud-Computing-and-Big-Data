import json
import boto3
import requests
import base64
import uuid
from base_rdb_service import BaseDataResource
from datetime import datetime
import urllib.parse
from opensearchpy import OpenSearch, RequestsHttpConnection

DB_SCHEMA = "6998db"
product_table = "Product"
product_tag_table = "product_tag"
user_product_table = "user_product"
user_table = "User"


    
def lambda_handler(event, context):
    # print(event)
    # TODO implement
    
    # http_request= event['http_request']
    # del event['http_request']
    
    # if http_request=='POST':
       
    # print('event',event)
    # un = event['uid']['username']
    un = event["uid"]
    
    template = {"uid": un}
    res = BaseDataResource.find_by_template(DB_SCHEMA, user_table, template)
    # print(res)
    # print(type(res))
        # json_ob = {
        #     "pid": pid,
        #     "tag": tag
        # }
        # print("json_ob: ", json_ob)
        #index_product(json_ob)

    out = ''
    out += res[0]['uid']
    out += '|'
    out += res[0]['email']
    out += '|'
    out += res[0]['description']
    # {'uid': 'hando', 'firstName': 'albus', 'lastName': 'cao', 'email': 'dh3071@columbia.edu', 'description': 'try profile'}
#   return True
    return {
        'statusCode': 200,
        'body': json.dumps(out)
    }