import json
import boto3
import requests
import base64
import uuid
from base_rdb_service import BaseDataResource
from datetime import datetime

DB_SCHEMA = "6998db"
product_table = "Product"
product_tag_table = "product_tag"


def search_this_week(pid_set):
    now = datetime.now()
    dt_string = now.strftime("%Y/%m/%d %H:%M:%S")
    dt_obj = datetime.strptime(dt_string, '%Y/%m/%d %H:%M:%S')
    print(dt_obj)
    created_time = dt_string
    products = {}
  
    res = BaseDataResource.find_by_template(DB_SCHEMA, product_table, created_date=created_time, days=7)
    print("res: ", res)
    
    for item in res:
        print(type(item["created_time"]))
        pid_set.add(item['pid'])
        
    return pid_set
    

def search_product_by_tag(keyword, pid_set):
    template = {"tag": keyword}
    
    res = BaseDataResource.find_by_template(DB_SCHEMA, product_tag_table, template)
    print(res)
    
    for item in res:
        pid_set.add(item['pid'])
    
    return pid_set
    
def opensearch_product_by_tag(keyword, pid_set):
    headers = { "Content-Type": "application/json" }
    ENDPOINT = "https://vpc-finalproj-tpa64scimd5iiaugmg3ii57nlu.us-east-1.es.amazonaws.com"
    
    url = ENDPOINT + '/_search?q=' + keyword
    response = requests.get(url, headers=headers, auth=("master", "Cc900929718!")).json()
    print(response)
    
    for item in response["hits"]["hits"]:
        pid_set.add(item["_source"]["pid"])
        
    return pid_set

    
def search_product_by_name(keyword, pid_set):
    res = BaseDataResource.get_by_prefix(DB_SCHEMA, product_table, "name", keyword)
    print("res: ", res)
    for item in res:
        pid_set.add(item['pid'])
        
    return pid_set
    

def get_product_detail(pid_set):
    products = []
    for pid in pid_set:
        product = {}
        res = BaseDataResource.find_by_template(DB_SCHEMA, product_table, {"pid": pid})
        
        if len(res) != 0:
            print(res[0])
            if res[0]['is_deleted'] == 0:
                #del res[0]['created_time']
                res[0]['created_time'] = str(res[0]['created_time'])
                product['product'] = res[0]
                res = BaseDataResource.find_by_template(DB_SCHEMA, "user_product", {"pid": pid})
                if len(res) != 0:
                    uid = res[0]['uid']
                    # print("uid: ", uid )
                    res = BaseDataResource.find_by_template(DB_SCHEMA, "User", {"uid": uid})
                    # print("res: ", res)
                    user_info = res[0]
                    product['user'] = user_info
                    # print("user_info: ", user_info)
                
                res = BaseDataResource.find_by_template(DB_SCHEMA, "product_tag", {"pid": pid})
                tags = []
                if len(res) != 0:
                    for r in res:
                        tags.append(r['tag'])
                    product['tag'] = tags
                    # print(tags)
                    
                
                products.append(product)
    
    return products


def lambda_handler(event, context):
    # TODO implement
    print(event)
    
    search_keyword = event["q"]
    print(search_keyword)
    
    pid_set = set()
    if search_keyword == "qwertyuiop":
        pid_set = search_this_week(pid_set)
        
    else:
        search_keyword = search_keyword.lower()
        # pid_set = search_product_by_tag(search_keyword, pid_set)
        pid_set = search_product_by_name(search_keyword, pid_set)
        pid_set = opensearch_product_by_tag(search_keyword, pid_set)
        # print("pid_set: ",len(pid_set))
    
    products = get_product_detail(pid_set)
    
    return {
        'statusCode': 200,
        'body': products
    }
    
    