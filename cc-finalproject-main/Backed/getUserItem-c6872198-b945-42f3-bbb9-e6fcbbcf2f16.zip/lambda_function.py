import json
import boto3
from base_rdb_service import BaseDataResource

DB_SCHEMA = "6998db"
user_product_table = "user_product"
product_table = "Product"
product_tag_table = "product_tag"

def find_user_product(uid, final):
    res = BaseDataResource.find_by_template(DB_SCHEMA, user_product_table, template={"uid":uid})
    products = []
    for item in res:
        product = []
        pid = item['pid']
        res = BaseDataResource.find_by_template(DB_SCHEMA, product_tag_table, template={"pid":pid})
        tag = res[0]["tag"]
        res = BaseDataResource.find_by_template(DB_SCHEMA, product_table, template={"pid":pid})
        if res[0]["is_deleted"] == 0:
            del res[0]['created_time']
            del res[0]['is_deleted']
            del res[0]['email']
            
            print(res[0])
            
            props = ["pid", "price", "name", "description", "image_link"]
            for prop in props:
                product.append(str(res[0][prop]))
            
            product.append(tag)
            products.append("|".join(product))
    
    final = "|".join(products)
    print(final)
        
    return final
    

def lambda_handler(event, context):
    uid = event["uid"]
    final = uid + "|"
    final += find_user_product(uid, final)
    return {
        'statusCode': 200,
        'body': final
    }
