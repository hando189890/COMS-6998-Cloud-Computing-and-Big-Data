var userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);

// function getParams() {
//   let url = window.location.href;
//   if (url.indexOf("?") != -1) {
//     let obj = {};
//     let arr = url.slice(url.indexOf("?") + 1).split("&");
//     arr.forEach((item) => {
//       let param = item.split("=");
//       obj[param[0]] = param[1];
//     });
//     return obj;
//   }
//   return {};
// }

// async function getData() {
//   var cognitoUser = userPool.getCurrentUser();
//   if (cognitoUser) {
//     var myHeaders = new Headers();
//     myHeaders.append("x-api-key", "v1xdU1cCYc5MkgPEghUlt40ETcgJtcaTMsdLGWib");
//     // myHeaders.append("Content-Type", "application/json");
//     // myHeaders.append('Access-Control-Allow-Origin', '*');
//     // myHeaders.append("Access-Control-Allow-Methods", "OPTIONS,GET");

//     var requestOptions = {
//       method: "GET",
//       headers: myHeaders,
//     };

//     var url = "https://dr4scjprxc.execute-api.us-east-1.amazonaws.com/v1/getuseritem?uid=";
//     url += cognitoUser.username;
//     const response = await fetch(url, requestOptions);
//     const data = await response.json();
//     let result = data.body.split(",");
//     let uid = result[0].substr(1, result[0].length);
//     let products = [];
//     // [pid][price][name][description][image_link][tag]
//     for (let i = 1; i < result.length; i + 5) {
//       let temp = result;
//       products.push(temp.splice(i, i + 5));
//     }
//     let product = products.filter((item) => item[0] == getParams().pid)[0];
//     console.log(product);
//     console.log("check uid in pdetail")
//     console.log(uid)
//     $("#uidinfo").val("uid");
//     // $("#Username").attr("disabled", "disabled");
//     // $("#ProductId").val(product[0]);
//     // $("#ProductId").attr("disabled", "disabled");
//     // $("#price").val(product[1]);
//     // $("#name").val(product[2]);
//     // $("#tag").val(product[5]);
//     // $("#description").val(product[3]);
//     // if (!product[4]) return;
//     // $("#portrait").attr("src", product[4]);
//     // $("#portrait").removeClass("img-hidden");
//     // $("#chuans").removeClass("chuans");
//   }
// }

const addWishlist = async(tag) =>{
  var cognitoUser = userPool.getCurrentUser();

  if (cognitoUser) {
    var uid = cognitoUser.username
  }

  console.log("1111111111111111");

  console.log(uid);
  upload_data = { "http_request": "POST", "uid": uid, "tag": tag};
  console.log(upload_data);
  var myHeaders = new Headers();
  myHeaders.append("x-api-key", "v1xdU1cCYc5MkgPEghUlt40ETcgJtcaTMsdLGWib");
  myHeaders.append("Content-Type", "application/json");
  var requestOptions = {
      method: "POST",
      headers: myHeaders,
      body: JSON.stringify(upload_data),
      redirect: "follow",
  };
  fetch("https://dr4scjprxc.execute-api.us-east-1.amazonaws.com/v1/wishlist", requestOptions)
  .then((response) => response.text())
  .then((result) => console.log(result))
  .catch((error) => console.log("error", error));

};
  


const getuserP = async () => {
  var cognitoUser = userPool.getCurrentUser();
  if (cognitoUser == null){
    document.getElementById("ava").disabled = true;
    document.getElementById("addWishList").disabled = true;
  }
  if (cognitoUser) {
    var myHeaders = new Headers();
    myHeaders.append("x-api-key", "v1xdU1cCYc5MkgPEghUlt40ETcgJtcaTMsdLGWib");
    // myHeaders.append("Content-Type", "application/json");
    // myHeaders.append('Access-Control-Allow-Origin', '*');
    // myHeaders.append("Access-Control-Allow-Methods", "OPTIONS,GET");

    var requestOptions = {
      method: "GET",
      headers: myHeaders,
    };

    var url = "https://dr4scjprxc.execute-api.us-east-1.amazonaws.com/v1/userinfo?uid=";
    url += cognitoUser.username;
    const response = await fetch(url, requestOptions);
    // console.log(response);
    const data = await response.json();
    // console.log(data.body);
    const attrs = data.body.split("|");
    const username = attrs[0].slice(1);
    const email = attrs[1];
    // const profile = attrs[2].slice(0, -1);
    console.log("check user info p")
    console.log(username)
    console.log(email)
    // $("#uidinfo").val(username);
    // $("email").val(email);
    document.getElementById("email").value = email; 
    document.getElementById("uinfo").value = username; 
    document.getElementById("uinfo").disabled = true;
    if(cognitoUser == null){
      document.getElementById("ava").disabled = true;
    }
    

  }

  //   $(".info").empty();
  //   var html = "";
  //   html += `<div><li style="margin-left: 25px; font-size: 22px;"> ${username}</li></div>`;
  //   html += "<br>";
  //   html += `<div><li style="margin-left: 25px; font-size: 22px;">Email: ${email}</li></div>`;
  //   html += "<br>";
  //   html += `<div><li style="margin-left: 25px; font-size: 22px;">Description: ${profile}</li></div>`;
  //   $(".info").html(html);
  // } else {
  //   alert("Not Logged In");
  // }
};

$(document).ready(function () {
  checkLogin()
    getuserP();
    $("#addWishList").click(function () {
      tag = $("#prod-tag").text()
      addWishlist(tag)
      alert("Successfully added");

  });
});
