var userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);
var apiClient = apigClientFactory.newClient();
var token = null;

const signUp = () => {
  event.preventDefault();
  console.log("signup");
  // uploadrds()
  let attributeList = [];

  const username = document.querySelector("#username").value;
  const emailadd = document.querySelector("#email").value;
  if (!emailadd.includes('columbia.edu')) {
    alert('You must use your columbia.edu email to register!')
    return
  }
  // const name = document.querySelector("#name").value;
  const profile = document.querySelector("#profile").value;
  const password = document.querySelector("#password").value;

  attributeList.push(
    new AmazonCognitoIdentity.CognitoUserAttribute({
      Name: "email",
      Value: emailadd,
    })
  );
  attributeList.push(
    new AmazonCognitoIdentity.CognitoUserAttribute({
      Name: "profile",
      Value: profile,
    })
  );
  // attributeList.push(new AmazonCognitoIdentity.CognitoUserAttribute({
  //   Name: "name",
  //   Value: name,
  // }));
  // var email = new AmazonCognitoIdentity.CognitoUserAttribute({
  //   Name: "email",
  //   Value: emailadd,
  // });

  userPool.signUp(username, password, attributeList, null, function (err, result) {
    if (err) {
      alert(err);
    } else {
      location.href = "confirm.html#" + username;
    }
  });

  upload_data = { username: username, description: profile, email: emailadd };
  console.log("uploaddata");
  console.log(upload_data);

  var myHeaders = new Headers();
  myHeaders.append("x-api-key", "v1xdU1cCYc5MkgPEghUlt40ETcgJtcaTMsdLGWib");
  myHeaders.append("Content-Type", "application/json");

  var requestOptions = {
    method: "POST",
    headers: myHeaders,
    body: JSON.stringify(upload_data),
    redirect: "follow",
  };

  fetch("https://dr4scjprxc.execute-api.us-east-1.amazonaws.com/v1/userupload", requestOptions)
    .then((response) => response.text())
    .then((result) => console.log(result))
    .catch((error) => console.log("error", error));
};

const confirmCode = () => {
  event.preventDefault();
  const username = location.hash.substring(1);
  const cognitoUser = new AmazonCognitoIdentity.CognitoUser({
    Username: username,
    Pool: userPool,
  });
  const code = document.querySelector("#confirm").value;
  console.log("code =" + code);
  // location.href = "signin.html";
  cognitoUser.confirmRegistration(code, true, function (err, results) {
    // if (err) {
    //   alert(err);
    // } else {
    console.log("confirmed");
    location.href = "signin.html";
    // location.href = "myprofile.html";
    // }
  });
};

const resendCode = () => {
  event.preventDefault();
  const username = location.hash.substring(1);
  const cognitoUser = new AmazonCognitoIdentity.CognitoUser({
    Username: username,
    Pool: userPool,
  });
  cognitoUser.resendConfirmationCode(function (err) {
    if (err) {
      alert(err);
    }
  });
};

const signIn = () => {
  event.preventDefault();
  const username = document.querySelector("#username").value;
  const password = document.querySelector("#password").value;

  let authenticationData = {
    Username: username,
    Password: password,
  };

  var authenticationDetails = new AmazonCognitoIdentity.AuthenticationDetails(authenticationData);
  var userData = {
    Username: username,
    Pool: userPool,
  };

  var cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);
  cognitoUser.authenticateUser(authenticationDetails, {
    onSuccess: function () {
      // uploadrds()
      console.log("login success");
      location.href = "index.html";
    },
    onFailure: function (err) {
      alert(JSON.stringify(err));
    },
  });
};

// function uploadrds(){
//   console.log("check uploadrds")
//   const username = document.querySelector("#username").value;
//   const password = document.querySelector("#password").value;
//   const email = document.querySelector("#email").value;
//   const description = document.querySelector("#profile").value;

//   upload_data = { username: username, description: description, email: email };
//   console.log("uploaddata")
//   console.log(upload_data);

//   var myHeaders = new Headers();
//   myHeaders.append("x-api-key", "v1xdU1cCYc5MkgPEghUlt40ETcgJtcaTMsdLGWib");
//   myHeaders.append("Content-Type", "application/json");

//   var requestOptions = {
//     method: "POST",
//     headers: myHeaders,
//     body: JSON.stringify(upload_data),
//     redirect: "follow",
//   };

//   fetch("https://dr4scjprxc.execute-api.us-east-1.amazonaws.com/v1/userupload", requestOptions)
//     .then((response) => response.text())
//     .then((result) => console.log(result))
//     .catch((error) => console.log("error", error));
// }

const signOut = () => {
  console.log("sign out");
  // $('.info').empty()
  var cognitoUser = userPool.getCurrentUser();
  if (cognitoUser) {
     cognitoUser.signOut();
     location.href = "homepage.html";
     alert("Sucessfully SignOut")
  }
};

// const refreshLogin = () => {
//   const userBtn = document.querySelector(".user");
//   var cognitoUser = userPool.getCurrentUser();
//   if (cognitoUser != null) {
//     userBtn.innerHTML += cognitoUser.username;
// };

const checkLogin_upload = () => {
  var cognitoUser = userPool.getCurrentUser();
  console.log(cognitoUser.username);
  if (cognitoUser != null) {
    input = document.getElementById("email");
    input.value = cognitoUser.username;
  }
};

const checkLogin = () => {
  console.log("checkLogin is called");
  const login = false;
  const userBtn = document.querySelector(".user");
  const leftBtn = document.querySelector(".left");
  const rightBtn = document.querySelector(".right");
  var cognitoUser = userPool.getCurrentUser();

  console.log(cognitoUser);
  // getuserInfo(cognitoUser.username);
  // update(cognitoUser.username)
  // const user_info_list = [];
  // for (const property in cognitoUser.storage) {
  //   user_info_list.push(`${property}: ${cognitoUser.storage[property]}`);
  // }
  // console.log();
  // console.log(userPool.getUser();

  // var params = {
  //   AccessToken: user_info_list[1].split(':')[1] /* required */
  // };
  // AmazonCognitoIdentity.cognitoidentityserviceprovider.getUser(params, function(err, data) {
  //   if (err) console.log(err, err.stack); // an error occurred
  //   else     console.log(data);           // successful response
  // });

  if (cognitoUser != null) {
    if (userBtn != null) {
      userBtn.innerHTML = cognitoUser.username;
    }
    

    if (rightBtn != null) {
      rightBtn.style.display = 'none';
    }
    
  } else {
    if (leftBtn != null) {
      leftBtn.innerHTML = "Sign In";
    }
    if (rightBtn != null) {
      rightBtn.innerHTML = "Register";
    }
    
    
  }
};

const navTosignUp = () => {
  console.log("sign up");
  location.href = "signup.html";
};

const navTosignIn = () => {
  console.log("sign in");
  var cognitoUser = userPool.getCurrentUser();
  if (cognitoUser !== null) {
    location.href = "profile.html";
  } else {
    location.href = "signin.html";
  }
};

const getuserInfoNew = async () => {
  var cognitoUser = userPool.getCurrentUser();
  if (cognitoUser) {
    var myHeaders = new Headers();
    myHeaders.append("x-api-key", "v1xdU1cCYc5MkgPEghUlt40ETcgJtcaTMsdLGWib");
    // myHeaders.append("Content-Type", "application/json");
    // myHeaders.append('Access-Control-Allow-Origin', '*');
    // myHeaders.append("Access-Control-Allow-Methods", "OPTIONS,GET");

    var requestOptions = {
      method: "GET",
      headers: myHeaders,
    };

    var url = "https://dr4scjprxc.execute-api.us-east-1.amazonaws.com/v1/userinfo?uid=";
    url += cognitoUser.username;
    const response = await fetch(url, requestOptions);
    // console.log(response);
    const data = await response.json();
    // console.log(data.body);
    const attrs = data.body.split("|");
    const username = attrs[0].slice(1);
    const email = attrs[1];
    const profile = attrs[2].slice(0, -1);
    // $("#useruid").val(username)
    console.log("app subscribe info")
    console.log(username)
    console.log(email)
    document.getElementById("useruid").value = username
    document.getElementById('useruid').disabled = true;

    $("#info").empty();
    var html = "";
    html += `<div><li style="margin-left: 25px; font-size: 22px;">Email: ${email}</li></div>`;
    html += "<br>";
    html += `<div><li style="margin-left: 25px; font-size: 22px;">Description: ${profile}</li></div>`;
    $("#info").html(html);
  } else {
    alert("Not Logged In");
  }
};

const getuserItem = async () => {
  var cognitoUser = userPool.getCurrentUser();
  if (cognitoUser) {
    var myHeaders = new Headers();
    myHeaders.append("x-api-key", "v1xdU1cCYc5MkgPEghUlt40ETcgJtcaTMsdLGWib");
    // myHeaders.append("Content-Type", "application/json");
    // myHeaders.append('Access-Control-Allow-Origin', '*');
    // myHeaders.append("Access-Control-Allow-Methods", "OPTIONS,GET");

    var requestOptions = {
      method: "GET",
      headers: myHeaders,
    };

    var url = "https://dr4scjprxc.execute-api.us-east-1.amazonaws.com/v1/getuseritem?uid=";
    url += cognitoUser.username;
    const response = await fetch(url, requestOptions);
    // console.log(response);
    const data = await response.json();
    let result = data.body.split("|");
    let uid = result[0];
    let products = [];
    // [pid][price][name][description][image_link][tag]
    for (let i = 1; i < result.length; i + 5) {
      let temp = result;
      products.push(temp.splice(i, i + 5));
    }

    console.log("check product user item")
    console.log(products)
    console.log(products[0])


    let html='';

    if (products[0] != ""){
    products.map((item, index) => {
      if (products.length == 0) return;
      html =
        html +
        ` <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
        <div class="product-card">
            <div class="product-bg">
                <a href="edition.html?pid=${item[0]}"><img style="width:auto; height:auto;"src="${
                  item[4]
        }" class="zoomIn prod-img" data-wow-delay=".25s"
                        data-wow-duration="1s" data-wow-iteration="1" alt=""></a>
            </div>
            <div class="product-content">
                <h5><a href="edition.html?pid=${item[0]}">${item[2]}</a></h5>
                <p>Avaliable !</p>
                <h4 class="price-text">${item[5] ? `<span class="tag">${item[5]}</span>` : ""}$${
                  item[1]
        }</h4>
            </div>
        </div>
    </div>`;
    });
  }
    $("#prod-con").append(html);
  } else {
    alert("Not Logged In");
  }

};

// function getuserInfo(){
//   console.log("get user info check")
//   let q = "toy"
//   var myHeaders = new Headers();
//   myHeaders.append("x-api-key", "v1xdU1cCYc5MkgPEghUlt40ETcgJtcaTMsdLGWib");
//   myHeaders.append("Content-Type", "application/json");

//   var requestOptions = {
//     method: "GET",
//     headers: myHeaders,
//     redirect: "follow",
//   };

//   fetch(
//     "https://dr4scjprxc.execute-api.us-east-1.amazonaws.com/v1/productsearch?q=" + q,
//     requestOptions
//   )
//     .then((response) => response.text())
//     .then((result) => result.text())
//     // .then(function (result) => response.text(){
//     //   //console.log(JSON.parse(result)['body'])
//     //   products = JSON.parse(result)["body"];
//     // })
//     .catch((error) => console.log("error", error));
//   }

// var cognitoUser = userPool.getCurrentUser();
// username = cognitoUser.username;
// console.log("check get user info profile ")
// console.log(username);

// var myHeaders = new Headers();
// myHeaders.append("x-api-key", "v1xdU1cCYc5MkgPEghUlt40ETcgJtcaTMsdLGWib");
// myHeaders.append("Content-Type", "application/text");

// search_data = { "username": username};

// var requestOptions = {
//   method: "GET",
//   headers: myHeaders,
//   body: JSON.stringify(search_data),
//   redirect: "follow",
// };
// const response = fetch("https://dr4scjprxc.execute-api.us-east-1.amazonaws.com/v1/getuserinfo", requestOptions)
// .then((response) => response.text())
// .then((result) => console.log(result))
// .catch((error) => console.log("error", error));
// console.log("reponse request")
// console.log(response)

// function update(username){
//   console.log("check update profile ")
//   console.log(username);

//   var myHeaders = new Headers();
//   myHeaders.append("x-api-key", "v1xdU1cCYc5MkgPEghUlt40ETcgJtcaTMsdLGWib");
//   myHeaders.append("Content-Type", myFile.type);

//   var requestOptions = {
//     method: "GET",
//     headers: myHeaders,
//     body: myFile,
//     redirect: "follow",
//   };

//   fetch(
//     " https://dr4scjprxc.execute-api.us-east-1.amazonaws.com/v1/getuseritem/" +
//       name,
//     requestOptions
//   )
//     .then((response) => response.text())
//     .then((result) => console.log(result))
//     .catch((error) => console.log("error", error));

// }

// const loadUsers = () => {
//   console.log('Load user is called');
//   getJWTToken_new(function (token) {
//     apiClient
//       .usersGet({}, null, { headers: { Authorization: token } })
//       .then(function (result) {
//         console.log(result);
//         // displayUsers(result.data);
//       })
//       .catch((err) => console.log(err));
//   });

// var cognitoUser = userPool.getCurrentUser();
// if (cognitoUser != null) {
//     cognitoUser.getUserAttributes(function(err, result){
//     console.log(err);
//     console.log(result);
//   });
// $(".info").empty()
// var html = ""
// curName = ognitoUser.username
// curDes = result[2]['Value']
// curEmail = result[3]['Value']
// html += `<div><li style="font-size: 22px; "> ${curName}</li></div>`
// html += '<br>'
// html += `<div><li style="font-size: 22px;">Email: ${curEmail}</li></div>`
// html += '<br>'
// html += `<div><li style="font-size: 22px;">Description: ${curDes}</li></div>`
// $(".info").html(html);
// }
// getJWTToken(function (token) {
//   apiClient
//     .usersGet({}, null, { headers: { Authorization: token } })
//     .then(function (result) {
//       console.log('result in loadusers');
//       console.log(result);
//       displayUsers(result.data);
//     })
//     .catch((err) => console.log(err));
// });
// };

function refresh() {
  const userBtn = document.querySelector(".user");
  var cognitoUser = userPool.getCurrentUser();
  if (cognitoUser != null) {
    userBtn.innerHTML += cognitoUser.username;
  }
}

function displayUsers(data) {
  const chatContainer = document.querySelector(".container");
  data.forEach((user) => {
    // <div class="conv">
    //     <p class="conv-text">Student - frank</p>
    //     <button class="conv-btn">details</button>
    // </div>
    const div = document.createElement("div");
    div.classList.add("conv");

    const p = document.createElement("p");
    p.classList.add("conv-text");
    p.innerText = user.Username;
    div.appendChild(p);

    const t = document.createElement("p");
    t.classList.add("time");
    t.innerText = "today";
    div.appendChild(t);

    const btn = document.createElement("button");
    btn.classList.add("conv-btn");
    //btn.innerHTML = '<i class="fas fa-comment"></i>';
    btn.innerText = "Start Chat";
    btn.addEventListener("click", () => startChat(user.Username));
    div.appendChild(btn);
    chatContainer.append(div);
  });
}

function startChat(userName) {
  console.log(userName);
  //postChats();
  location.href = "chat.html#" + userName;
}

// const getUserInfo = () => {

//   console.log('get user info')
//   var cognitoUser = userPool.getCurrentUser();
//   // if (cognitoUser != null) {
//   //   cognitoUser.getUserAttributes(function(err, result))
//   // }
//   var html =""
//   if (cognitoUser != null) {
//       cognitoUser.getUserAttributes(function(err, result){
//          if (err) {
//             alert(err.message || JSON.stringify(err));
//             return;
//           } // err
//         if (result.length == 0){
//           console.log("check empty result");
//           $("#info").append("No Result")
//         }
//         else{
//             curName = result[0]['Name']
//             curDes = result[2]['Value']
//             curEmail = result[3]['Value']
//             html += curEmail
//             $('.tre').html(html)
//             }
//       } // cognitoUser.getUserAttributes
//       )}; //if cognitoUser != null
// };

const navToUpload = () => {
  console.log("sign in");
  var cognitoUser = userPool.getCurrentUser();
  if (cognitoUser !== null) {
    location.href = "upload.html";
  } else {
    location.href = "signin.html";
  }
};

function getJWTToken_new(callback) {
  if (token == null) {
    var cognitoUser = userPool.getCurrentUser();
    if (cognitoUser != null) {
      cognitoUser.getSession(function (err, session) {
        if (err) {
          location.href = "index.html";
        }
        token = session.getIdToken().getJwtToken();
        console.log("---------------");
        console.log(token);
        console.log("---------------");
        callback(token);
      });
    }
  } else {
    callback(token);
  }
}

function getJWTToken(callback) {
  if (token == null) {
    var cognitoUser = userPool.getCurrentUser();
    console.log("getJWTToken");
    console.log(cognitoUser);
    if (cognitoUser != null) {
      cognitoUser.getSession(function (err, session) {
        if (err) {
          location.href = "index.html";
        }
        token = session.getIdToken().getJwtToken();

        // console.log("check token2")
        // console.log(token);
        //updateProfile(token)
        cognitoUser.getUserAttributes(function (err, result) {
          if (err) {
            alert(err.message || JSON.stringify(err));
            return;
          }
          console.log("check data result");
          console.log(result);
          console.log("start update");
          $(".info").empty();
          var html = "";
          console.log("start update2");
          console.log(html);
          if (result.length == 0) {
            console.log("check empty result");
            $("#info").append("No Result");
          } else {
            console.log(result[0]);
            console.log(result[0]["Name"]);
            curName = result[0]["Name"];
            curDes = result[2]["Value"];
            curEmail = result[3]["Value"];
            console.log("check profile");
            console.log(curName);
            console.log(curDes);
            console.log(curEmail);
            html += `<div><li style="font-size: 22px; "> ${curName}</li></div>`;
            html += "<br>";
            html += `<div><li style="font-size: 22px;">Email: ${curEmail}</li></div>`;
            html += "<br>";
            html += `<div><li style="font-size: 22px;">Description: ${curDes}</li></div>`;
            $(".info").html(html);
          }

          // callback(result)
          // updateProfile(result)

          //   for (i = 0; i < result.length; i++) {

          //   console.log(
          //       'attribute ' + result[i].getName() + ' has value ' + result[i].getValue()
          //  );
          // }
        });

        console.log();
        console.log("---------------");
        console.log(token);
        console.log("---------------");
        callback(token);
      });
    }
  } else {
    callback(token);
  }
}

function updateProfile(result) {
  console.log("start update");
  $("#info").empty();
  var html = "";
  console.log("start update2");
  console.log(html);
  if (result.length == 0) {
    console.log("check empty result");
    $("#info").append("No Result");
  } else {
    curName = result[0][Name];
    curDes = result[2][Value];
    curName = result[3][Value];
    console.log("check profile");
    console.log(curName);
    console.log(curDes);
    console.log(curName);
    html += `<div><h2 style="font-size: 22px;">Height: ${curName}</h2></div>`;
    html += "<br>";
    $("#info").html(html);
  }
}

function hashString(s) {
  return s.split("").reduce(function (a, b) {
    a = (a << 5) - a + b.charCodeAt(0);
    return a & a;
  }, 0);
}
function getUniqueName(curUser, otherUser) {
  curUser = curUser.toLowerCase();
  otherUser = otherUser.toLowerCase();

  let user_name = curUser + "_" + otherUser;
  if (curUser.length === otherUser.length) {
    if (hashString(curUser) < hashString(otherUser)) {
      return otherUser + "_" + curUser;
    }
  } else if (otherUser.length > curUser.length) {
    return otherUser + "_" + curUser;
  }
  return user_name;
}

function loadChatDetails(otherUser) {
  getJWTToken(function (token) {
    let cognitoUser = userPool.getCurrentUser();
    let curUser = cognitoUser.username;
    let unique_name = getUniqueName(curUser, otherUser);
    apiClient
      .chatsGet({ sender_receiver: unique_name }, null, { headers: { Authorization: token } })
      .then(function (result) {
        console.log(result);
        chats = result.data;
        displayChatDetails(chats, curUser, otherUser);
      })
      .catch((err) => console.log(err));
  });
}

function displayChatDetails(chats, curUser, otherUser) {
  const chatContainer = document.querySelector(".message-container");
  chatContainer.innerHTML = "";
  //console.log("chats= " + conv.messages);
  //const messages = conv.messages;
  const defaultUser = curUser;
  chats.forEach((chat) => {
    // <div class="message left">
    //      <p class="sender">sender</p>
    //      <p class="msg-text">This is a sample message</p>
    //      <p class="time">15 minutes ago</p>
    // </div>
    // div
    const direction = chat.sender === defaultUser ? "left" : "right";
    const div = document.createElement("div");
    div.classList.add("message");
    div.classList.add(direction);

    const pSender = document.createElement("p");
    pSender.classList.add("sender");
    pSender.innerText = chat.sender;
    div.appendChild(pSender);

    const pMessage = document.createElement("p");
    pMessage.classList.add("msg-text");
    pMessage.innerText = chat.message;
    div.appendChild(pMessage);

    const pTime = document.createElement("p");
    pTime.classList.add("time");
    console.log("time = " + chat.unixtime);
    const d = new Date(Number(chat.unixtime) * 1000);
    console.log("date = " + d);
    pTime.innerText = moment(d).fromNow();
    div.appendChild(pTime);

    chatContainer.appendChild(div);
  });
}

function postChat() {
  let cognitoUser = userPool.getCurrentUser();
  let curUser = cognitoUser.username;
  otherUser = location.hash.substring(1);

  let unique_name = getUniqueName(curUser, otherUser);

  const msgInput = document.querySelector(".msg-input");
  var msg = msgInput.value;
  if (msg === "") return;
  msgInput.value = "";
  console.log("post chat !" + msg);

  const now = new Date();
  const secondsSinceEpoch = Math.round(now.getTime() / 1000);

  var payload = {
    sender_receiver: unique_name,
    unixtime: secondsSinceEpoch,
    sender: curUser,
    receiver: otherUser,
    message: msg,
  };
  apiClient
    .chatsPost({ sender_receiver: unique_name }, payload, { headers: { Authorization: token } })
    .then(function (result) {
      console.log("success post !");
      console.log(result);
    })
    .catch((err) => console.log(err));
}
