
function addItem(){
  console.log("add item in subscribe")
  let subtag = $("#addItemValue").val();
  let uid = $("#useruid").val();
  console.log(subtag)
  pid = "try subscribe tage"
  tag = subtag
  // upload_data = { "http_request": "POST", "pid": pid, "price": price, "name": name, "description": description, "tag": tag, "email": uid};
  upload_data = { "http_request": "POST", "pid": pid, "tag": tag, "uid":uid};
  console.log("upload_data");
  console.log(upload_data);

  var myHeaders = new Headers();
  myHeaders.append("x-api-key", "v1xdU1cCYc5MkgPEghUlt40ETcgJtcaTMsdLGWib");
  myHeaders.append("Content-Type", "application/json");

  var requestOptions = {
    method: "POST",
    headers: myHeaders,
    body: JSON.stringify(upload_data),
    redirect: "follow",
  };

  fetch("https://dr4scjprxc.execute-api.us-east-1.amazonaws.com/v1/upload", requestOptions)
    .then((response) => response.text())
    .then((result) => console.log(result))
    .catch((error) => console.log("error", error));
}

// function f1(){
//   Alert(`${click.Value}`)
// }

$(document).ready(function () {
  $(".button2").click(function() {
    console.log("check point 1")
    var fired_button = $(this).val();
    console.log(fired_button)
    // alert(fired_button);
  });

});
