var poolData = {
    UserPoolId: "us-east-1_BnVDyDj1g", // Please provide yours
    ClientId: "7d7hlv3de66m1lhf8vvrk3bopq", // Please provide yours
};

const checkLogin_other = () => {
    var userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);
    var cognitoUser = userPool.getCurrentUser();
    console.log(cognitoUser.username);
    if (cognitoUser != null) {
        $("#user-name").text(cognitoUser.username)
    }
    else {
        $("#user-name").text("Your account")
    }
};



function getInfo() {
    let url = window.location.href; 
    if (url.indexOf("?") != -1) {
      let obj = {};
      let arr = url.slice(url.indexOf("?") + 1).split("&");
      arr.forEach((item) => {
        let param = item.split("=");
        obj[param[0]] = param[1];
      });
      return obj;
    }
    return {};
}


async function getuserInfoOther() {
    let uid = getInfo().uid;

    var myHeaders = new Headers();
    myHeaders.append("x-api-key", "v1xdU1cCYc5MkgPEghUlt40ETcgJtcaTMsdLGWib");

    var requestOptions = {
        method: "GET",
        headers: myHeaders,
    };

    let res = await fetch(
        "https://dr4scjprxc.execute-api.us-east-1.amazonaws.com/v1/userinfo?uid="+uid,
        requestOptions
    ).then((res) => {
        return res.json();
    });
    let user = res["body"]
    console.log(user)
    const attrs = user.split("|");
    const username = attrs[0].slice(1);
    const email = attrs[1];
    const description = attrs[2].slice(0, -1);
    
    console.log("app subscribe info")
    console.log(username)
    console.log(email)
    console.log(description)

    $("#info").empty();
    var html = "";
    html += `<div><li style="margin-left: 25px; font-size: 22px;">Email: ${email}</li></div>`;
    html += "<br>";
    html += `<div><li style="margin-left: 25px; font-size: 22px;">Description: ${description}</li></div>`;
    $("#info").html(html);

    $("#othername").empty();
    $("#othername").text(username + "'s Profile")
    $("#otheruserinterests").text(username + "'s Interest")
    $("#otheruserprod").text(username + "'s Products")
    $("#otheruserinfo").text(username + "'s Information")
};


const getuserItem = async () => {
    let uid = getInfo().uid;

    var myHeaders = new Headers();
    myHeaders.append("x-api-key", "v1xdU1cCYc5MkgPEghUlt40ETcgJtcaTMsdLGWib");

    var requestOptions = {
    method: "GET",
    headers: myHeaders,
    };

    var url = "https://dr4scjprxc.execute-api.us-east-1.amazonaws.com/v1/getuseritem?uid=";
    url += uid;
    const response = await fetch(url, requestOptions);
    // console.log(response);
    const data = await response.json();
    let result = data.body.split("|");
    let username = result[0].substr(1, result[0].length);
    let products = [];
    for (let i = 1; i < result.length; i + 5) {
    let temp = result;
    products.push(temp.splice(i, i + 5));
    }

    let html='';

    products.map((item, index) => {
    if (products.length == 0) return;
    html =
        html +
        ` <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
        <div class="product-card">
            <div class="product-bg">
                <a href="productDetail.html?pid=${item[0]}"><img style="width:auto; height:auto;"src="${
                item[4]
        }" class="zoomIn prod-img" data-wow-delay=".25s"
                        data-wow-duration="1s" data-wow-iteration="1" alt=""></a>
            </div>
            <div class="product-content">
                <h5><a href="productDetail.html?pid=${item[0]}">${item[2]}</a></h5>
                <p>Avaliable !</p>
                <h4 class="price-text">${item[5] ? `<span class="tag">${item[5]}</span>` : ""}$${
                item[1]
        }</h4>
            </div>
        </div>
    </div>`;
    });
    $("#prod-con").append(html);
};


const getotheruserTag = async () => {
    let uid = getInfo().uid;
  
    var myHeaders = new Headers();
    myHeaders.append("x-api-key", "v1xdU1cCYc5MkgPEghUlt40ETcgJtcaTMsdLGWib");
    myHeaders.append("Content-Type", "application/json");
  
    var requestOptions = {
      method: "GET",
      headers: myHeaders,
      redirect: "follow",
    };
  
    let r = await fetch(
      "https://dr4scjprxc.execute-api.us-east-1.amazonaws.com/v1/wishlist?uid="+uid,
      requestOptions
    )
      .then((response) => response.text())
      .then(function (result) {
        
        //console.log(JSON.parse(result)['body'])
        products = JSON.parse(result)["body"];
        
      })
      .catch((error) => console.log("error", error));
      console.log(products);
      products = products.replace(/"/g,"")
      const attrs = products.split("|");
      console.log(attrs)
      // console.log(attrs[0])
      // console.log(attrs.length)
      $(".tags").empty()
      let html ="";
      if (attrs[0] != ""){
        for (let i = 0; i < attrs.length; i++) {
          console.log(attrs[i])
          html = html +
           ` <button class="button2 col-lg-6 col-md-6" onclick="alert('This user is interested in '+(this.value))" value=${attrs[i]}><span>${attrs[i]} </span></button>` 
        }
      }
      
      $(".tags").append(html);
      
      // <button class="button2" value="Electronic"><span>Electronic </span></button>
      // <button class="button2" value="Book"><span>Book </span></button>
}





$(document).ready(function () {

    checkLogin_other();
    getuserInfoOther();
    getuserItem();
    getotheruserTag();
})