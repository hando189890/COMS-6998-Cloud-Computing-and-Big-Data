function uploadimg(pid) {
  console.log("check uploadimg")
  // const myFile = $("#myFile").prop("files")[0];
  const myFile = $("#myFile").prop("files")[0];
  console.log("check myFile")
  console.log(myFile)
  let name = pid;
  console.log(name)

  var myHeaders = new Headers();
  myHeaders.append("x-api-key", "v1xdU1cCYc5MkgPEghUlt40ETcgJtcaTMsdLGWib");
  myHeaders.append("Content-Type", myFile.type);

  var requestOptions = {
    method: "PUT",
    headers: myHeaders,
    body: myFile,
    redirect: "follow",
  };

  fetch(
    "https://dr4scjprxc.execute-api.us-east-1.amazonaws.com/v1/upload-img-s3/final-photobucket/" +
      name,
    requestOptions
  )
    .then((response) => response.text())
    .then((result) => console.log(result))
    .catch((error) => console.log("error", error));
}

function post_info(pid) {
  console.log("check upload inof")
  let price = $("#price").val();
  let name = $("#name").val();
  let description = $("#description").val();
  let tag = $("#tag").val();
  let uid = $("#email").val();
  console.log("profile")
  console.log(price)
  console.log(name)
  console.log(description)
  console.log(tag)
  // console.log(uid)

  upload_data = { "http_request": "PUT", "pid": pid, "price": price, "name": name, "description": description, "tag": tag, "email": uid};
  console.log(upload_data);

  var myHeaders = new Headers();
  myHeaders.append("x-api-key", "v1xdU1cCYc5MkgPEghUlt40ETcgJtcaTMsdLGWib");
  myHeaders.append("Content-Type", "application/json");

  var requestOptions = {
    method: "PUT",
    headers: myHeaders,
    body: JSON.stringify(upload_data),
    redirect: "follow",
  };

  fetch("https://dr4scjprxc.execute-api.us-east-1.amazonaws.com/v1/upload", requestOptions)
    .then((response) => response.text())
    .then((result) => console.log(result))
    .catch((error) => console.log("error", error));
}


function deleting(pid){
  console.log("deleting")
  console.log(pid)

  delete_data ={"http_request": "DELETE", "pid": pid}
  
  var myHeaders = new Headers();
  myHeaders.append("x-api-key", "v1xdU1cCYc5MkgPEghUlt40ETcgJtcaTMsdLGWib");
  myHeaders.append("Content-Type", "application/json");

  var requestOptions = {
    method: "PUT",
    headers: myHeaders,
    body: JSON.stringify(delete_data),
    redirect: "follow",
  };

  fetch("https://dr4scjprxc.execute-api.us-east-1.amazonaws.com/v1/upload", requestOptions)
    .then((response) => response.text())
    .then((result) => console.log(result))
    .catch((error) => console.log("error", error));

}

function clear(){
   $("#price").val("");
   $("#name").val("");
   $("#description").val("");
   $("#tag").val("");
   $("#portrait").attr("src", "");
   $("#portrait").addClass("img-hidden");
   $("#chuans").addClass("chuans");
}



$(document).ready(function () {
  $("#upload").click(function () {
    let pid = $("#ProductId").val();
    uploadimg(pid.toString());
    post_info(pid.toString());
    alert("Successfully Upload");
    location.href = "profile.html"
  });
  $("#delete").click(function () {
    let pid = $("#ProductId").val();
    deleting(pid.toString());
    alert("Successfully Delete");
    location.href = "profile.html"
  });
  $("#clear").click(function () {
    clear();
  });
});