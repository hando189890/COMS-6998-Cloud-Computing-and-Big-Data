// function search() {

//     let searchkey = $("#search").val()
//     upload_data = {"searchkey": try}
//     console.log(upload_data)

//     var myHeaders = new Headers();
//         myHeaders.append("x-api-key", "v1xdU1cCYc5MkgPEghUlt40ETcgJtcaTMsdLGWib");
//         myHeaders.append("Content-Type", "application/json");

//     var requestOptions = {
//         method: 'GET',
//         headers: myHeaders,
//         body: JSON.stringify(upload_data),
//         redirect: 'follow'
//     };

//     fetch("https://dr4scjprxc.execute-api.us-east-1.amazonaws.com/v1/productsearch", requestOptions)
//         .then(response => response.text())
//         .then(result => console.log(result))
//         .catch(error => console.log('error', error));
// }
// function search(){
//         var searchTerm = document.getElementById("inputbox").value;
//         var apigClient = apigClientFactory.newClient({
//             apiKey: 'v1xdU1cCYc5MkgPEghUlt40ETcgJtcaTMsdLGWib'
//         });
//         var params = {
//             q: "bags"
//         };
//         var body = {

//         };

//         var additionalParams = {
//         };

//         console.log(searchTerm);
//         apigClient.searchGet(params, body, additionalParams).then(function(result){
//             console.log('success OK');
//             console.log(result)
//             console.log(result.data.body.results);
//             // var photos = result.data.body.results;
//             // var container = document.getElementById("photos");

//             // for (var i=0, len = photos.length; i < len; ++i) {
//             //     var img = new Image(200,200);
//             //     img.src = photos[i].url;
//             //     img.style.padding = "15px";

//             //     document.getElementById('container').appendChild(img);
//             //}
//         }).catch( function(result){
//                 console.log("cur2");
//                 console.log(result);
//         });
// }

var poolData = {
  UserPoolId: "us-east-1_BnVDyDj1g", // Please provide yours
  ClientId: "7d7hlv3de66m1lhf8vvrk3bopq", // Please provide yours
};
const checkLogin_upload = () => {
  var userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);
  var cognitoUser = userPool.getCurrentUser();
  console.log(cognitoUser.username);
  if (cognitoUser != null) {
    $("#user-name").text(cognitoUser.username)
  }
  else {
    $("#user-name").text("I am here")
  }
};

async function search() {
  var searchTerm = document.getElementById("searchinput").value;
  console.log(searchTerm);
  document.getElementById("searchinput").value = "";
  let q = "qwertyuiopa"
  if (searchTerm != ""){
    q = searchTerm;
  }
  
  var myHeaders = new Headers();
  myHeaders.append("x-api-key", "v1xdU1cCYc5MkgPEghUlt40ETcgJtcaTMsdLGWib");
  myHeaders.append("Content-Type", "application/json");

  var requestOptions = {
    method: "GET",
    headers: myHeaders,
    redirect: "follow",
  };
  console.log(q)
  let r = await fetch(
    "https://dr4scjprxc.execute-api.us-east-1.amazonaws.com/v1/productsearch?q=" + q,
    requestOptions
  )
    .then((response) => response.text())
    .then(function (result) {
      
      //console.log(JSON.parse(result)['body'])
      products = JSON.parse(result)["body"];
    })
    .catch((error) => console.log("error", error));

  console.log(products);
  $("#prod-con").empty()
  let html = "";

  products.map((item) => {
    // console.log(item);
    let product = item.product;
    let tag = item.tag ? item.tag : "";
    html =
      html +
      ` <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
      <div class="product-card">
          <div class="product-bg">
              <a href="productDetail.html?pid=${product.pid}"><img style="width:auto; height:auto;"src="${
        product.image_link
      }" class="zoomIn prod-img" data-wow-delay=".25s"
                      data-wow-duration="1s" data-wow-iteration="1" alt=""></a>
          </div>
          <div class="product-content">
              <h5><a href="productDetail.html?pid=${product.pid}">${product.name}</a></h5>
              <p>Avaliable !</p>
              <h4 class="price-text">${tag ? `<span class="tag">${tag[0]}</span>` : ""}$${
        product.price
      }</h4>
          </div>
      </div>
  </div>`;
  });
  $("#prod-con").append(html);
  
  if (html == "") {
    $("#search-result").hide()
    //$("#footer").css("margin-top","20rem")
  }
  else {
    $("#search-result").show()
  }

  //   $.each(products, function (value, index) {
  //     console.log(products);
  //   });
}

// $(document).ready(function() {
//     // $('#upload').click(function() {
//     //     let pid = uuidv4()
//     //     uploadimg(pid.toString())
//     //     post_info(pid.toString())
//     //     alert("good")
//     // });

//     $("#searchbutton").click(function() {
//         search()
//         alert("yes")
//     })
// });

$(document).ready(function () {
  search();
  checkLogin_upload();
});
