var useremail =""
var username = ""
var productname = ""
var productprice = ""
var productdes = ""



function getInfo() {
  let url = window.location.href; 
  if (url.indexOf("?") != -1) {
    let obj = {};
    let arr = url.slice(url.indexOf("?") + 1).split("&");
    arr.forEach((item) => {
      let param = item.split("=");
      obj[param[0]] = param[1];
    });
    return obj;
  }
  return {};
}


async function getproduct() {
  let pid = getInfo().pid;
  let res = await fetch(
    "https://dr4scjprxc.execute-api.us-east-1.amazonaws.com/v1/productsearch?q="+pid
  ).then((res) => {
    return res.json();
  });

  let product = res.body[0];
  console.log(product)

  productname = product.product.name
  productprice = product.product.price
  productdes = product.product.description
  producttime = product.product.created_time
  producttag = product.tag[0]
  
  product.user?product.user.email: useremail="None" 
  product.user?product.user.uid: username="None"
  
  console.log(product.user)
  if (useremail != "None"){
    useremail = product.user.email
  }

  if (username != "None"){
    username = product.user.uid
  }



  let seller_name = product.user?product.user.uid:""
  let seller_email = product.user?product.user.email:""
  let seller_description = product.user?product.user.description:""
  $("#sell-name").text(seller_name)
  $("#sell-email").text(seller_email)
  $("#sell-des").text(seller_description)

  $("#prod-name").text(productname)
  $("#prod-price").text("$" + productprice)
  $("#prod-tag").text(producttag)
  $("#prod-time").text(producttime)
  $("#sell-name-link").attr("href","otherProfile.html?uid="+seller_name)


  $("#p-img").attr("src", product.product.image_link)


  let html = `
<div class="row mt-5">
  <div class="col-sm-8 mt-5 pt-5">
      <div class="row">
          <div class="col-sm-7">
              <img src="${product.product.image_link}" class="img-responsive">
          </div>
          <div class="ml-5 pro-desc">
              <div class="mt-4">
              ${product.product.name}
              </div>
              <div class="mt-4 pro-price">
                  $ ${product.product.price}
              </div>
              <div class="mt-4">
                  Detail: <span class="pro-detail">
                  ${product.product.description}
                  </span>
              </div>
          </div>
      </div>
      <div class="mt-5 text-center">
          <button class="btn AddBtn">
              Add to WishiList
          </button>
      </div>
  </div>
  <div class="col-sm-4 pro-rig p-4">
      <h3>
          Seller Information
      </h3>
      <div class="user">
          <img src="https://preview.redd.it/i1m7fcpmbzv81.png?width=1920&format=png&auto=webp&s=1f2abb28b18061727d70c29ec8a5dca6d3766ceb"
              alt="">
          <div class="mt-3">
              Name: <a href=" ">${product.user?product.user.uid:""}</a >
          </div>
          <div class="mb-3">
              Email: ${product.user?product.user.email:""}
          </div>
      </div>
  </div>
</div>`;
  $("#proDetail").append(html);
  searchRelatedProd(producttag, pid);
}

const getuserItemP = async (username, pid) => {
  // var cognitoUser = userPool.getCurrentUser();
  if (username != null) {
    var myHeaders = new Headers();
    myHeaders.append("x-api-key", "v1xdU1cCYc5MkgPEghUlt40ETcgJtcaTMsdLGWib");

    var requestOptions = {
      method: "GET",
      headers: myHeaders,
    };

    var url = "https://dr4scjprxc.execute-api.us-east-1.amazonaws.com/v1/getuseritem?uid=";
    url += username;
    const response = await fetch(url, requestOptions);
    const data = await response.json();
    let result = data.body.split(",");
    let uid = result[0].substr(1, result[0].length);
    let products = [];
    // [pid][price][name][description][image_link][tag]
    for (let i = 1; i < result.length; i + 5) {
      let temp = result;
      products.push(temp.splice(i, i + 5));
    }

    let final = []
    for (let i = 0; i < products.length; i++) {
       if (pid != products[i][0]){
         final.push(products[i])
       }
    }



    let html='';
    final.map((item, index) => {
      if (index == final.length - 1) return;

    html =
      html +
      ` <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
      <div class="product-card">
          <div class="product-bg">
              <a href="productDetail.html?pid=${item[0]}">< img src="${
                item[4]
      }" class="zoomIn prod-img" data-wow-delay=".25s"
                      data-wow-duration="1s" data-wow-iteration="1" alt=""></a >
          </div>
          <div class="product-content">
              <h5><a href="productDetail.html?pid=${item[0]}">${item[2]}</a ></h5>
              <p>Avaliable !</p >
              <h4 class="price-text">${item[5] ? `<span class="tag">${item[5]}</span>` : ""}$${
                item[1]
      }</h4>
          </div>
      </div>
  </div>`;
    });
    $("#prod-con").append(html);
  } else {
    alert("Not Logged In");
  }

};


async function searchRelatedProd(producttag, pid) {
    const q = producttag
    console.log("q")
    console.log(q)
    
    var myHeaders = new Headers();
    myHeaders.append("x-api-key", "v1xdU1cCYc5MkgPEghUlt40ETcgJtcaTMsdLGWib");
    myHeaders.append("Content-Type", "application/json");
  
    var requestOptions = {
      method: "GET",
      headers: myHeaders,
      redirect: "follow",
    };
    let r = await fetch(
      "https://dr4scjprxc.execute-api.us-east-1.amazonaws.com/v1/productsearch?q=" + q,
      requestOptions
    )
      .then((response) => response.text())
      .then(function (result) {
        products = JSON.parse(result)["body"];
        console.log(products)
        products = products.filter((item) => item.product.pid != pid);
      })
      .catch((error) => console.log("error", error));
  
    $("#relatedProd").empty()
    let html = "";
    products.map((item) => {
      let product = item.product;
      let tag = item.tag ? item.tag : "";
      html =
        html +
        ` <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
        <div class="product-card">
            <div class="product-bg">
                <a href="productDetail.html?pid=${product.pid}"><img style="width:100%;"src="${
          product.image_link
        }" class="zoomIn prod-img" data-wow-delay=".25s"
                        data-wow-duration="1s" data-wow-iteration="1" alt=""></a >
            </div>
            <div class="product-content">
                <h5><a href="productDetail.html?pid=${product.pid}">${product.name}</a ></h5>
                <p>Avaliable !</p >
                <h4 class="price-text">${tag ? `<span class="tag">${tag[0]}</span>` : ""}$${
          product.price
        }</h4>
            </div>
        </div>
    </div>`;
    });
    $("#relatedProd").append(html);
}

function connect(){
    const semail = useremail
    const suid = username
    const pname = productname 
    const pprice = productprice
    const pdes = productdes
    const cemail = document.getElementById('email').value;
    const cphone= document.getElementById('phone').value;
    const cdescript= document.getElementById('description').value;
    const cuid = document.getElementById('uinfo').value;


    upload_data = { "http_request": "POST", 
                    "semail": semail, "suid": suid, 
                    "pname": pname, "pprice": pprice, "pdes": pdes, 
                    "cuid":cuid, "cemail": cemail, "cphone": cphone, "cdescript": cdescript};

  var myHeaders = new Headers();
  myHeaders.append("x-api-key", "v1xdU1cCYc5MkgPEghUlt40ETcgJtcaTMsdLGWib");
  myHeaders.append("Content-Type", "application/json");

  var requestOptions = {
    method: "POST",
    headers: myHeaders,
    body: JSON.stringify(upload_data),
    redirect: "follow",
  };

  fetch("https://dr4scjprxc.execute-api.us-east-1.amazonaws.com/v1/contactseller", requestOptions)
    .then((response) => response.text())
    .then((result) => console.log(result))
    .catch((error) => console.log("error", error));

}

$(document).ready(function () {
  getproduct();
  //var producttag = getproduct();
  // console.log("global")
  // console.log(producttag)
  // producttag.then(function (result) {
  //   console.log(1)
  //   tag = result;
  //   console.log(tag)
  // })
  // console.log(tag)
  
  $("#ava").click(function(){
    connect()
    alert("Message Send")
  });
});