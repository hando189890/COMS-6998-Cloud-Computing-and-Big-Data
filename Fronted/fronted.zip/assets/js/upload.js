
function uploadimg(pid) {
  const myFile = $("#myFile").prop("files")[0];
  let name = pid;
  console.log("check my file")
  console.log(myFile)

  var myHeaders = new Headers();
  myHeaders.append("x-api-key", "v1xdU1cCYc5MkgPEghUlt40ETcgJtcaTMsdLGWib");
  myHeaders.append("Content-Type", myFile.type);

  var requestOptions = {
    method: "PUT",
    headers: myHeaders,
    body: myFile,
    redirect: "follow",
  };

  fetch(
    "https://dr4scjprxc.execute-api.us-east-1.amazonaws.com/v1/upload-img-s3/final-photobucket/" +
      name,
    requestOptions
  )
    .then((response) => response.text())
    .then((result) => console.log(result))
    .catch((error) => console.log("error", error));
}

function post_info(pid) {
  let price = $("#price").val();
  let name = $("#name").val();
  let description = $("#description").val();
  let tag = $("#tag").val();
  let uid = $("#email").val();
  console.log(uid)
  upload_data = { "http_request": "POST", "pid": pid, "price": price, "name": name, "description": description, "tag": tag, "email": uid};
  console.log(upload_data);

  var myHeaders = new Headers();
  myHeaders.append("x-api-key", "v1xdU1cCYc5MkgPEghUlt40ETcgJtcaTMsdLGWib");
  myHeaders.append("Content-Type", "application/json");

  var requestOptions = {
    method: "POST",
    headers: myHeaders,
    body: JSON.stringify(upload_data),
    redirect: "follow",
  };

  fetch("https://dr4scjprxc.execute-api.us-east-1.amazonaws.com/v1/upload", requestOptions)
    .then((response) => response.text())
    .then((result) => console.log(result))
    .catch((error) => console.log("error", error));
}

function uuidv4() {
  return ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, (c) =>
    (c ^ (crypto.getRandomValues(new Uint8Array(1))[0] & (15 >> (c / 4)))).toString(16)
  );
}

function preview() {
  $("#myFile").on("change", (el) => {
    const myFile = document.getElementById("myFile").files[0];
    var fileReader = new FileReader();
    fileReader.readAsDataURL(myFile);
    fileReader.onload = function () {
      var data = this.result;
      $("#portrait").attr("src", data);
      $("#portrait").removeClass("img-hidden");
      $("#chuans").removeClass("chuans");
    };
  });
}

function Cancel() {
  $("#Cancel").click(function () {
    $("#price").val("");
    $("#name").val("");
    $("#description").val("");
    $("#tag").val("");
    $("#portrait").attr("src", "");
    $("#portrait").addClass("img-hidden");
    $("#chuans").addClass("chuans");
  });
}

// function addItem(){
//   console.log("add item")
//   let subtag = $("#addItemValue").val();
//   let uid = $("#useruid").val();
//   console.log(subtag)
//   pid = "try subscribe tage"
//   tag = subtag
//   // upload_data = { "http_request": "POST", "pid": pid, "price": price, "name": name, "description": description, "tag": tag, "email": uid};
//   upload_data = { "http_request": "POST", "pid": pid, "tag": tag, "uid":uid};
//   console.log("upload_data");
//   console.log(upload_data);

//   var myHeaders = new Headers();
//   myHeaders.append("x-api-key", "v1xdU1cCYc5MkgPEghUlt40ETcgJtcaTMsdLGWib");
//   myHeaders.append("Content-Type", "application/json");

//   var requestOptions = {
//     method: "POST",
//     headers: myHeaders,
//     body: JSON.stringify(upload_data),
//     redirect: "follow",
//   };

//   fetch("https://dr4scjprxc.execute-api.us-east-1.amazonaws.com/v1/upload", requestOptions)
//     .then((response) => response.text())
//     .then((result) => console.log(result))
//     .catch((error) => console.log("error", error));
// }

$(document).ready(function () {
  preview();
  Cancel();
  $("#upload").click(function () {
    let pid = uuidv4();
    uploadimg(pid.toString());
    post_info(pid.toString());
    alert("Successfully Upload");
    location.href = "profile.html"
    Cancel()
  });
});
