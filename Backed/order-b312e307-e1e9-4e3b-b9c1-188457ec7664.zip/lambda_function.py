import json
from base_rdb_service import BaseDataResource


def lambda_handler(event, context):
    # TODO implement
    
    
    res = BaseDataResource.create(
        "6998db","Order",{"oid": "1", "buyer":"123", "seller":"ww25", "pid":"p1","dateTime":"2022-04-19 00:00:00"}
        )
    print(res)
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }