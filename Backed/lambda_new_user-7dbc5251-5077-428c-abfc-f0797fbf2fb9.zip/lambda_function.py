import json
import boto3
import requests
import base64 
import uuid
from base_rdb_service import BaseDataResource

DB_SCHEMA = "6998db"
usertable = "User"

def lambda_handler(event, context):
    # print(event)
    # print(event.userName)
    # print(event.request.userAttributes.profile)
    # print(event.request.userAttributes.email)
    # return True
    
    
    username = event["userName"]
    description = event["request"]["userAttributes"]["profile"]
    email = event["request"]["userAttributes"]["email"]
    firstName = "F"
    lastName = "L"
    print(username)
    print(description)
    print(email)
        
    # {'version': '1', 
    # 'region': 'us-east-1', 
    # 'userPoolId': 'us-east-1_BnVDyDj1g', 
    # 'userName': 'l1', 
    # 'callerContext': {'awsSdkVersion': 'aws-sdk-unknown-unknown', 'clientId': '7d7hlv3de66m1lhf8vvrk3bopq'}, 
    # 'triggerSource': 'PostConfirmation_ConfirmSignUp', 
    # 'request': {'userAttributes': 
    #               {'sub': '76aa3e93-6593-4b42-8fc9-7719bef8b2ea', 
    #               'cognito:email_alias': 'dh3071@columbia.edu', 
    #               'email_verified': 'true', 
    #               'cognito:user_status': 'CONFIRMED', 
    #               'profile': 'l1 try', 
    #               'email': 'dh3071@columbia.edu'}}, 'response': {}}

       
    
    res = BaseDataResource.create("6998db", "User",{"uid": username,"firstName": firstName, "lastName": lastName, "email":email, "description":description})
        
    print(res)
    
    # return {
    #     'statusCode': 200,
    #     'body': json.dumps('Hello from Lambda!')
    # }