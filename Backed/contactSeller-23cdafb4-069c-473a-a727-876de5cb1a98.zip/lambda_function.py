import json
import email
import os
import re
import boto3


def format_email(event):
    product_name = event["pname"]
    product_price = event["pprice"]
    customer_name = event["cuid"]
    customer_phone = event["cphone"]
    customer_email = event["cemail"]
    customer_info = event["cdescript"]
    formed_email = "Dear User:\nThe {} you are selling at price ${} has received some interests.\n".format(product_name, str(product_price)) 
    formed_email += "The buyer's infomation is as following:\nName: {}\nPhone#: {}\nEmail: {}\n".format(customer_name, customer_phone, customer_email)
    formed_email += "The message from the customer is: {}".format(customer_info)
    
    print(formed_email)
    return formed_email
    
def send_ses(sender_email, formed_email):

    client = boto3.client('ses')
    # print(sender_email)
    response = client.send_email(
        Source="customer@yukizhang.today",
        Destination={
            'ToAddresses': [
                sender_email
            ]},
        Message={
            'Subject': {
                'Data': "You have receive an email regarding the product for sale"
            },
            'Body': {
                'Text': {
                    'Data': formed_email
                }
            }
        })
        
    print(response)
    

def lambda_handler(event, context):
    # TODO implement
    
    http_request= event['http_request']
    del event['http_request']
    
    if http_request=='POST':
        seller_email = event["semail"]
        formed_email = format_email(event)
        send_ses(seller_email, formed_email)
    
    # send_ses("yz3983@columbia.edu", "nihao")

        
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }