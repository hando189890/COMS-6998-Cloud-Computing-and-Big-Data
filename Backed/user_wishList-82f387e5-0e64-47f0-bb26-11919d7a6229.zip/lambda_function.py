import json
import boto3
import requests
import base64
from base_rdb_service import BaseDataResource

DB_SCHEMA = "6998db"
TABLE = "wish_list"


def get_wishlist(uid):
    data = {"uid": uid}
    try:
        res = BaseDataResource.find_by_template(DB_SCHEMA, TABLE, data)
        print(res)
        print(type(res))
        tags = []
        for item in res:
            tags.append(item["tag"])
    
    except Exception as e:
        return {'statusCode': 500, "body": e}
        
    return {'statusCode': 200, "body":json.dumps("|".join(tags))}


def add_wishlist(uid, tag):
    data = {"uid": uid, "tag": tag}
    try:
        res = BaseDataResource.create(DB_SCHEMA, TABLE, data)
    
    except Exception as e:
        return {'statusCode': 500, "body": e}
        
    return {'statusCode': 200, "body":"Successfully upload this tag from your wishlist."}
    

def delete_wishlist(uid, tag):
    data = {"uid": uid, "tag": tag}
    
    try:
        res = BaseDataResource.delete(DB_SCHEMA, TABLE, data)
    
    except Exception as e:
        return {'statusCode': 500, "body": e}
    
    return {'statusCode': 200, "body":"Successfully deleted this tag from your wishlist."}
    

def lambda_handler(event, context):
    # TODO implement
    uid = event['uid']
    if "http_request" not in event:
        res = get_wishlist(uid)
        return res
    
    
    http_request= event['http_request']
    tag = event['tag']
        
    
    if http_request=='POST':
        res = add_wishlist(uid, tag)
    
    if http_request=='DELETE':
        res = delete_wishlist(uid, tag)
        
    return res

