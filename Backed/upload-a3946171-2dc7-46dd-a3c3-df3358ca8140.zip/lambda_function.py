import json
import boto3
import requests
import base64
import uuid
from base_rdb_service import BaseDataResource
from datetime import datetime
import urllib.parse
from opensearchpy import OpenSearch, RequestsHttpConnection

DB_SCHEMA = "6998db"
product_table = "Product"
product_tag_table = "product_tag"
user_product_table = "user_product"

    
def creat_product(event):
    product_info = event.copy()
    del product_info['tag']
    
    uid = event["email"]
    pid = event["pid"]
    tag = event["tag"]
    
    now = datetime.now()
    dt_string = now.strftime("%d/%m/%Y %H:%M:%S")
    dt_obj = datetime.strptime(dt_string, '%d/%m/%Y %H:%M:%S')
    image_link = "https://final-photobucket.s3.amazonaws.com/" + product_info["pid"]
    
    product_info["created_time"] = dt_obj
    product_info["image_link"] = image_link
    print(product_info)
   
    try:
        res = BaseDataResource.create(DB_SCHEMA, product_table, product_info)
        res = BaseDataResource.create(DB_SCHEMA, user_product_table, {"uid":uid, "pid":pid})
        res = BaseDataResource.create(DB_SCHEMA, product_tag_table, {"pid":pid, "tag":tag})
        
        json_ob = {
            "pid":pid,
            "tag":tag.lower(),
            "created_time":dt_string}
        
        index_product(json_ob) 
        
    except Exception as e:
        return {'statusCode': 500, "body": e}
        
    return {'statusCode': 200, "body":"Successfully updated this product."}
    
    
def delete_product(product_info):
    update_info = {"is_deleted": 1}
    try:
        res = BaseDataResource.update(DB_SCHEMA, product_table, update_info, product_info)
        
    except Exception as e:
        return {'statusCode': 500, "body": e}
        
    return {'statusCode': 200, "body":"Successfully deleted this product."}

def update_product(event):
    update_info = event.copy()
    del update_info['pid']
    del update_info['tag']
    pid = event["pid"]
    tag = event["tag"]
        
    now = datetime.now()
    dt_string = now.strftime("%d/%m/%Y %H:%M:%S")
    dt_obj = datetime.strptime(dt_string, '%d/%m/%Y %H:%M:%S')
    
    try:
        res = BaseDataResource.update(DB_SCHEMA, product_table, update_info, {"pid":pid})
        res = BaseDataResource.update(DB_SCHEMA, product_tag_table, {"tag":tag}, {"pid":pid})
    except Exception as e:
        return {'statusCode': 500, "body": json.dumps(e)}
    
    return {'statusCode': 200, "body":"Successfully updated this product."}

  
def index_product(json_ob):
    headers = { "Content-Type": "application/json" }
    ENDPOINT = "https://vpc-finalproj-tpa64scimd5iiaugmg3ii57nlu.us-east-1.es.amazonaws.com"
    url = ENDPOINT + '/index/create'
    response = requests.post(url, headers=headers, auth=("master", "Cc900929718!"), json=json_ob).json()
    print(response)
    print("yes we are here!!!!")
    
def lambda_handler(event, context):
    # TODO implement
    
    http_request= event['http_request']
    del event['http_request']
    
    if http_request=='POST':
        res = creat_product(event)
        print("upload: ", res)

        
    if http_request=='PUT':
        pid = event["pid"]
        res = update_product(event)
        if "Error" in res:
            return {
                'statusCode': 500,
                'body': json.dumps(res["Error"])
            }
        print("update: ", res)

        
    if http_request=="DELETE":
        res = delete_product(event)
        print("delete: ", res)
        
        
    return res